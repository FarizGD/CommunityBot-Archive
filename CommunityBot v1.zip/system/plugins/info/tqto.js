module.exports = {
  command: "tqto",
  alias: ["credit"],
  category: ["info"],
  description: "📜 Daftar Kontributor Bot Ini",
  async run(m) {
    let cap = `*– 乂 Terima Kasih Kepada*\n\n`;
    cap += `> 🙌 *Bang_syaii*\n`;
    cap += `>   🛠️ *Peran:* Pembuat Script & Scraper Bot\n`;
    cap += `>   🔗 *Telegram:* [Klik di sini](https://t.me/this_syaii)\n\n`;
    cap += `> 🙌 *AxellNetwork*\n`;
    cap += `>   🛠️ *Peran:* Pengembang Script & Scraper Bot\n`;
    cap += `>   🔗 *GitHub:* [Klik di sini](https://github.com/AxellNetwork)\n\n`;
    cap += `> 🙌 *Pengguna Script*\n`;
    cap += `>   ❤️ Kalian semua yang sudah mendukung dan menggunakan script ini!\n\n`;
    cap += `📜 *Ucapan Terima Kasih*\n`;
    cap += `Terima kasih telah menggunakan script ini. Semoga bermanfaat bagi Anda, baik yang menggunakan maupun tidak menggunakan.\n\n`;
    cap += `🌟 *Dukung Proyek Kami Lainnya:*\n`;
    cap += `🔗 [GitHub AxellNetwork](https://github.com/AxellNetwork)\n\n`;
    cap += `*– Forum & Komunitas*\n`;
    cap += `> 📢 [Forum Update](https://whatsapp.com/channel/0029VauJgduEwEjwwVwLnw37)\n`;
    cap += `> 💬 [Join Grup](https://chat.whatsapp.com/BsZHPiZoisT5GdVgiEufJK)`;

    m.reply(cap);
  },
};
